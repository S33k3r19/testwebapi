﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TesWebAppAPI.Models;

namespace TesWebAppAPI.Data
{
    public class TesWebAppAPIContext : DbContext
    {
        public TesWebAppAPIContext (DbContextOptions<TesWebAppAPIContext> options)
            : base(options)
        {
        }

        public DbSet<TesWebAppAPI.Models.VolunteerModel> VolunteerModel { get; set; } = default!;
    }
}
