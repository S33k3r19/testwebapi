﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TesWebAppAPI.Data;
using TesWebAppAPI.Models;

namespace TesWebAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VolunteerController : ControllerBase
    {
        private readonly TesWebAppAPIContext _context;

        public VolunteerController(TesWebAppAPIContext context)
        {
            _context = context;
        }

        // GET: api/Volunteer
        [HttpGet]
        public async Task<ActionResult<IEnumerable<VolunteerModel>>> GetVolunteerModel()
        {
            return await _context.VolunteerModel.ToListAsync();
        }

        // GET: api/Volunteer/5
        [HttpGet("{id}")]
        public async Task<ActionResult<VolunteerModel>> GetVolunteerModel(Guid id)
        {
            var volunteerModel = await _context.VolunteerModel.FindAsync(id);

            if (volunteerModel == null)
            {
                return NotFound();
            }

            return volunteerModel;
        }

        // PUT: api/Volunteer/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutVolunteerModel(Guid id, VolunteerModel volunteerModel)
        {
            if (id != volunteerModel.CompanyId)
            {
                return BadRequest();
            }

            _context.Entry(volunteerModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VolunteerModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Volunteer
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<VolunteerModel>> PostVolunteerModel(VolunteerModel volunteerModel)
        {
            _context.VolunteerModel.Add(volunteerModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetVolunteerModel", new { id = volunteerModel.CompanyId }, volunteerModel);
        }

        // DELETE: api/Volunteer/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVolunteerModel(Guid id)
        {
            var volunteerModel = await _context.VolunteerModel.FindAsync(id);
            if (volunteerModel == null)
            {
                return NotFound();
            }

            _context.VolunteerModel.Remove(volunteerModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool VolunteerModelExists(Guid id)
        {
            return _context.VolunteerModel.Any(e => e.CompanyId == id);
        }
    }
}
