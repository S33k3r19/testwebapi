﻿namespace VolunteerAPI.Models
{
    public class VolunteerModel
    {
        public string CompanyName { get; set; }
        public string NPWP { get; set; }
        public string DirectorName { get; set; }
        public string PICName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
