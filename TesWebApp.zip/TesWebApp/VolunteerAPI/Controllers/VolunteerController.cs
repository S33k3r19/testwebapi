﻿using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using VolunteerAPI.Models;

namespace VolunteerAPI.Controllers
{
    public class VolunteerController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:7041/api");
        private readonly HttpClient _client;

        public VolunteerController()
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(VolunteerModel volunteer)
        {
            string data = JsonConvert.SerializeObject(volunteer);
            StringContent content = new StringContent(data, System.Text.Encoding.UTF8,"application/json");

            HttpResponseMessage response = _client.PostAsync(_client.BaseAddress + "Volunteer", content).Result;

            if (response.IsSuccessStatusCode)
            {
                TempData["successmessage"] = "product created.";
                return RedirectToAction("index");
            }

            return View();

        }
    }
}
